package com.mooddle.muddleteste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuddletesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
